#!/bin/bash

function ctrl_c(){
	echo -e "\e[33;1m 	* Saliendo \n\n"
	rm -rf file.tmp file2.tmp
	exit 1
}

trap ctrl_c INT

if [ -f "$1" ];then
	echo -e "\e[36;1mEl archivo $1\e[0m"
	echo -ne "\e[36;1mDesea sobrescribir este archivo?\e[0m" ; read NULL
	rm -rf $1
fi

if [[ ! -n $1 ]];then
	echo -e "\n\e[35;1m	* ?nombre de archivo a buscar\n\n"
	exit 1
fi


echo -e "\n\n\e[35;1m Generando rutas con la indicacion del archivo : $1\n	* Espere..\e[0m"
tput civis

for i in $(seq 1 $(cat ./wordlists/rutas.txt | wc -l)); do

	sed 's/\(.*\)\/[^\/]*$/\1/' ./wordlists/rutas.txt >> file.tmp
	echo """$(cat file.tmp | awk "NR==$i")/$1""" >> file2.tmp

done

sort file2.tmp | uniq  >> "you_wordlists.txt"


rm -rf file.tmp file2.tmp
echo -e "	\e[35;1m * Archivo $1 generado correctamente\e[0m\n"
tput cnorm




